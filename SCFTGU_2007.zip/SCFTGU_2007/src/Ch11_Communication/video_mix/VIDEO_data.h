// VIDEO_data.h

typedef unsigned YCRCB_frame;
typedef float MIXER_ctrl;
typedef unsigned MIXER_state;
typedef unsigned RGB_frame;
typedef unsigned YCRCB_frame;

