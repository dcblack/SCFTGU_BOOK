#include <stdio.h>
void Hello_C() {
  printf("Hello C\n");
}
int main(int argc, char* argv[]) {
  Hello_C();
  return 0;
}
